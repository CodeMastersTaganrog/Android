package com.example.neuromusic;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Register extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        final Button bt = findViewById(R.id.button_register);
        final EditText name = findViewById(R.id.name_register);
        final EditText surname = findViewById(R.id.surname_register);
        final EditText email = findViewById(R.id.email_register);
        final EditText password = findViewById(R.id.password_register);

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), CheckConnect.class);
                startActivity(intent);
            }
        });
    }
}
